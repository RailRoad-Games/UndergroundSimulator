// Source code is decompiled from a .class file using FernFlower decompiler (from Intellij IDEA).
package de.qstudios.underground.core;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import de.qstudios.underground.util.Strecke;
import de.qstudios.underground.util.Zug;

public class Firma {
   public String name;
   public int geld;
   public int fahrer;
   public List<Zug> zuege;
   public List<Strecke> strecken;
   public int manager = 0;

   public Firma(String name) {
      this.name = name;
      this.geld = 500;
      this.fahrer = 1;
      this.manager = 0;
      this.zuege = new LinkedList();
      this.zuege.add(new Zug(120, "Stadler", 60));
      this.strecken = new LinkedList();
      this.strecken.add(new Strecke());
   }

   public String getName() {
      return this.name;
   }

   public int getGeld() {
      return this.geld;
   }

   public void setFahrer(int fahrer) {
      this.fahrer = fahrer;
   }

   public void addGeld(int betrag) {
      this.geld += betrag;
   }

   public void setGeld(int betrag) {
      this.geld = betrag;
   }

   public int getFahrer() {
      return this.fahrer;
   }

   public void addFahrer(int anzahl) {
      this.fahrer += anzahl;
   }

   public List<Zug> getZug() {
      return this.zuege;
   }

   public int getManager() {
      return this.manager;
   }

   public void setManager(int manager) {
      this.manager = manager;
   }

   public void addZug(Zug z) {
      this.zuege.add(z);
   }

   public List<Strecke> getStrecke() {
      return this.strecken;
   }

   public void addStrecke(Strecke s) {
      this.strecken.add(s);
   }

   public String toString() {
      int haltestellenZahl = 0;

      Strecke s;
      for(Iterator var2 = this.strecken.iterator(); var2.hasNext(); haltestellenZahl += s.haltestellen.size()) {
         s = (Strecke)var2.next();
      }

      String var10000 = this.name;
      return "Ihre Firma heist " + var10000 + ", Sie haben " + this.geld + " €, Sie sind Arbeitgeber von " + this.fahrer + " Fahrer(n), Sie betreiben " + this.zuege.size() + " Züge & bewirtschafen " + this.strecken.size() + " Strecken mit insgesamt " + haltestellenZahl + " Haltestellen!";
   }
}
