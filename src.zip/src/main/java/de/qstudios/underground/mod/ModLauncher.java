// Source code is decompiled from a .class file using FernFlower decompiler (from Intellij IDEA).
package de.qstudios.underground.mod;

import java.io.File;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Iterator;
import java.util.jar.Attributes;
import java.util.jar.JarFile;
import java.util.jar.Manifest;

public class ModLauncher {
   public ModLauncher() {
   }

  /*@deprecated
   @Deprecated
   public static void launchAllModsXML(String methodName) {
      Iterator var1 = ModManager.mods.iterator();

      while(true) {
         while(var1.hasNext()) {
            Mod mod = (Mod)var1.next();
            String jarPath = (String)ModManager.extensions.getOrDefault(mod.getName(), (Object)null);
            if (jarPath == null) {
               System.err.println("Kein JAR für Mod \"" + mod.getName() + "\" gefunden.");
            } else {
               File jarFile = new File(jarPath);
               if (!jarFile.exists()) {
                  System.err.println("Mod-JAR nicht gefunden: " + jarFile.getAbsolutePath());
               } else {
                  try {
                     URLClassLoader classLoader = new URLClassLoader(new URL[]{jarFile.toURI().toURL()}, ModLauncher.class.getClassLoader());

                     label99: {
                        label98: {
                           label97: {
                              try {
                                 JarFile jar = new JarFile(jarFile);

                                 label93: {
                                    label92: {
                                       label91: {
                                          try {
                                             Manifest manifest = jar.getManifest();
                                             if (manifest != null) {
                                                String mainClassName = manifest.getMainAttributes().getValue("Main-Class");
                                                if (mainClassName == null) {
                                                   System.err.println("Main-Class fehlt in " + jarFile.getName());
                                                   break label92;
                                                }

                                                Class<?> clazz = classLoader.loadClass(mainClassName);
                                                Object instance = clazz.getDeclaredConstructor().newInstance();
                                                if (!(instance instanceof Modfile)) {
                                                   System.err.println("Error while loading mods: mainclass imlements not Modfile.");
                                                   break label93;
                                                }

                                                try {
                                                   Method m = clazz.getMethod(methodName);
                                                   m.invoke(instance);
                                                } catch (NoSuchMethodException var14) {
                                                }
                                                break label91;
                                             }

                                             System.err.println("Manifest fehlt in " + jarFile.getName());
                                          } catch (Throwable var15) {
                                             try {
                                                jar.close();
                                             } catch (Throwable var13) {
                                                var15.addSuppressed(var13);
                                             }

                                             throw var15;
                                          }

                                          jar.close();
                                          break label98;
                                       }

                                       jar.close();
                                       break label99;
                                    }

                                    jar.close();
                                    break label97;
                                 }

                                 jar.close();
                              } catch (Throwable var16) {
                                 try {
                                    classLoader.close();
                                 } catch (Throwable var12) {
                                    var16.addSuppressed(var12);
                                 }

                                 throw var16;
                              }

                              classLoader.close();
                              continue;
                           }

                           classLoader.close();
                           continue;
                        }

                        classLoader.close();
                        continue;
                     }

                     classLoader.close();
                  } catch (Exception var17) {
                     System.err.println("❌ Fehler beim Laden der Mod \"" + mod.getName() + "\":");
                     var17.printStackTrace();
                  }
               }
            }
         }

         return;
      }
   }*/

   public static void LaunchAllModsJSON(String methodName) {
      Iterator var1 = ExtensionJson.get(ModManager.getModsDir()).iterator();

      while(var1.hasNext()) {
         ExtensionJson extensionJson = (ExtensionJson)var1.next();
         Extension ext = extensionJson.getExtension();
         File jarFile = ext.getFile();
         if (!jarFile.exists()) {
            System.err.println("Mod-JAR nicht gefunden: " + jarFile.getAbsolutePath());
            return;
         }

         try {
            URLClassLoader classLoader = new URLClassLoader(new URL[]{jarFile.toURI().toURL()}, ModLauncher.class.getClassLoader());

            label94: {
               label93: {
                  label92: {
                     try {
                        JarFile jar = new JarFile(jarFile);

                        label88: {
                           label87: {
                              label86: {
                                 try {
                                    Manifest manifest = jar.getManifest();
                                    if (manifest == null) {
                                       System.err.println("Manifest nicht gefunden.");
                                       break label86;
                                    }

                                    Attributes attr = manifest.getMainAttributes();
                                    String mainClassName = attr.getValue("Main-Class");
                                    if (mainClassName != null) {
                                       Class<?> clazz = classLoader.loadClass(mainClassName);
                                       Object instance = clazz.getDeclaredConstructor().newInstance();
                                       if (!(instance instanceof Modfile)) {
                                          System.err.println("Die Klasse " + mainClassName + " implementiert Modfile nicht.");
                                          break label87;
                                       }

                                       try {
                                          Method m = clazz.getMethod(methodName);
                                          m.invoke(instance);
                                       } catch (NoSuchMethodException var16) {
                                          System.out.println("Mod hat keine Methode namens: " + methodName);
                                       }
                                       break label88;
                                    }

                                    System.err.println("Main-Class nicht im Manifest gefunden.");
                                 } catch (Throwable var17) {
                                    try {
                                       jar.close();
                                    } catch (Throwable var15) {
                                       var17.addSuppressed(var15);
                                    }

                                    throw var17;
                                 }

                                 jar.close();
                                 break label93;
                              }

                              jar.close();
                              break label94;
                           }

                           jar.close();
                           break label92;
                        }

                        jar.close();
                     } catch (Throwable var18) {
                        try {
                           classLoader.close();
                        } catch (Throwable var14) {
                           var18.addSuppressed(var14);
                        }

                        throw var18;
                     }

                     classLoader.close();
                     continue;
                  }

                  classLoader.close();
                  return;
               }

               classLoader.close();
               return;
            }

            classLoader.close();
            return;
         } catch (Exception var19) {
            System.err.println("Fehler beim Laden oder Ausführen der Mod:");
            var19.printStackTrace();
         }
      }

   }
}
