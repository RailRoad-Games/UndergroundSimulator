// Source code is decompiled from a .class file using FernFlower decompiler (from Intellij IDEA).
package de.qstudios.underground.mod;

/** @deprecated */
@Deprecated
public class Item {
   /** @deprecated */
   @Deprecated
   public String id;
   /** @deprecated */
   @Deprecated
   public String name;
   /** @deprecated */
   @Deprecated
   public String type;

   /** @deprecated */
   @Deprecated
   public Item(String id, String name, String type) {
      this.id = id;
      this.name = name;
      this.type = type;
   }

   public String getId() {
      return this.id;
   }

   public String getName() {
      return this.name;
   }

   public String getType() {
      return this.type;
   }
}
