// Source code is decompiled from a .class file using FernFlower decompiler (from Intellij IDEA).
package de.qstudios.underground.mod;

import java.util.Iterator;
import java.util.List;

/** @deprecated */
public class Mod {
   public String name;
   public String version;
   public String author;
   public String description;
   public List<Item> items;

   public Mod(String n, String v, String a, String d, List<Item> items) {
      this.name = n;
      this.version = v;
      this.author = a;
      this.description = d;
      this.items = items;
   }

   public String getName() {
      return this.name;
   }

   public String getVersion() {
      return this.version;
   }

   public String getAuthor() {
      return this.author;
   }

   public String getDescription() {
      return this.description;
   }

   public List<Item> getItems() {
      return this.items;
   }

   public String toString() {
      String var10000 = this.name;
      return "Mod {name='" + var10000 + "', version='" + this.version + "', author='" + this.author + "', description='" + this.description + "', items=" + String.valueOf(this.items) + "}";
   }

   public Item getItemById(String id) {
      Iterator var2 = this.items.iterator();

      Item item;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         item = (Item)var2.next();
      } while(!item.getId().equals(id));

      return item;
   }
}
