// Source code is decompiled from a .class file using FernFlower decompiler (from Intellij IDEA).
package de.qstudios.underground.mod;

import com.google.gson.Gson;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

public class ExtensionJson {
   private String name;
   private Double version;
   private String author;
   private String description;
   private Extension extension;
   public static ExtensionJson extensionJson;

   public ExtensionJson(String name, Double version, String author, String description, String where, String filePath) {
      new File(filePath);
      this.name = name;
      this.version = version;
      this.author = author;
      this.description = description;
      this.extension = new Extension(where, filePath);
   }

   /** @deprecated */
   public String getName() {
      return this.name;
   }

   public String toString() {
      return "Mod" + this.name + " der Version " + this.version + ", des Authors " + this.author + ", Beschreibung:" + this.description;
   }

   public void setName(String name) {
      this.name = name;
   }

   public Double getVersion() {
      return this.version;
   }

   public void setVersion(Double version) {
      this.version = version;
   }

   public String getAuthor() {
      return this.author;
   }

   public void setAuthor(String author) {
      this.author = author;
   }

   public String getDescription() {
      return this.description;
   }

   public void setDescription(String description) {
      this.description = description;
   }

   public Extension getExtension() {
      return this.extension;
   }

   public void setExtension(Extension extension) {
      this.extension = extension;
   }

   public static void main(String[] args) {
      String path = String.valueOf(ModManager.getModsDir()) + "/mod.json";
      ExtensionJson ext = loadFromFile(path);
      if (ext != null) {
         PrintStream var10000 = System.out;
         String var10001 = ext.getName();
         var10000.println("Extension geladen: " + var10001 + " erstellt von " + ext.getAuthor() + " (v" + ext.getVersion() + ")");
      } else {
         System.out.println("Fehler beim Laden der Extension.");
      }

   }

   public static ExtensionJson loadFromFile(String path) {
      try {
         Gson gson = new Gson();
         if (path.endsWith(".zip")) {
            ModManager.unzip(path, path.replace(".zip", ""));
            path = path.replace(".zip", File.separator + "mod.json");
         }

         String json = Files.readString(Paths.get(path));
         return (ExtensionJson)gson.fromJson(json, ExtensionJson.class);
      } catch (IOException var3) {
         var3.printStackTrace();
         return null;
      }
   }

   public static ArrayList<ExtensionJson> get(File where) {
      return read(ModManager.getModsDir());
   }

  private static ArrayList<ExtensionJson> read(File folder) {
    ArrayList<ExtensionJson> extensions = new ArrayList<>();

    if (folder == null || !folder.exists() || !folder.isDirectory()) {
        return extensions;
    }

    File[] files = folder.listFiles();

    if (files == null) {
        return extensions;
    }

    for (File fileEntry : files) {
        if (fileEntry.isDirectory()) {
            extensions.addAll(read(fileEntry)); // wichtig!
        } else if (fileEntry.getName().endsWith(".zip")) {
            ExtensionJson ext = loadFromFile(fileEntry.getAbsolutePath());
            extensions.add(ext);
        }
    }

    return extensions;
}
}
