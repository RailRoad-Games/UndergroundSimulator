// Source code is decompiled from a .class file using FernFlower decompiler (from Intellij IDEA).
package de.qstudios.underground.mod;

import com.google.gson.annotations.SerializedName;
import java.io.File;
import java.nio.file.Path;

public class Extension {
   /** @deprecated */
   public String where;
   @SerializedName("file")
   public String filePath;

   public Extension(String where, String filePath) {
      this.where = where;
      this.filePath = filePath;
   }

   public String getWhere() {
      return this.where;
   }

   public void setWhere(String where) {
      this.where = where;
   }

   public String getFilePath() {
      return this.filePath;
   }

   public void setFilePath(String filePath) {
      this.filePath = filePath;
   }

   public File getFile() {
      return new File(this.filePath);
   }

   public Path getFileAsPath() {
      return (new File(this.filePath)).toPath();
   }

   public String toString() {
      return "Extension [where=" + this.where + ", file=" + this.filePath + "]";
   }
}
