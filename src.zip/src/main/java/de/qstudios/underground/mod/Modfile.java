// Source code is decompiled from a .class file using FernFlower decompiler (from Intellij IDEA).
package de.qstudios.underground.mod;

public interface Modfile {
   void activity();

   void onLogin();

   void onLaunch();

   void onGameStart();
   
   void onEnable();
}
