package de.qstudios.underground.mod;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ModJson {
    public Logger getLogger(Class<?> cl) {
        return LoggerFactory.getLogger(cl.getClass());
    }
}
