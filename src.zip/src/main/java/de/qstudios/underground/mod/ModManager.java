// Source code is decompiled from a .class file using FernFlower decompiler (from Intellij IDEA).
package de.qstudios.underground.mod;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/** @deprecated */
@Deprecated
public class ModManager {
   public static HashMap<String, String> extensions = new HashMap<>();
   public static List<Mod> mods = new ArrayList<>();
   public static File modsDir;

   public ModManager() {
   }

   public static File getModsDir() {
      return modsDir;
   }

   public static void readMods() {
      if (modsDir.exists() && modsDir.isDirectory()) {
         File[] var0 = modsDir.listFiles((f) -> {
            return f.getName().endsWith(".zip");
         });
         int var1 = var0.length;

         for(int var2 = 0; var2 < var1; ++var2) {
            File modZip = var0[var2];

            try {
               String var10000 = String.valueOf(modsDir);
               String tempDir = var10000 + "/" + modZip.getName().replace(".zip", "");
               unzip(modZip.getAbsolutePath(), tempDir);
               File modJson = new File(tempDir + "/mod.json");
               if (modJson.exists()) {
                  ExtensionJson ext = ExtensionJson.loadFromFile(modJson.getAbsolutePath());
                  if (ext != null) {
                     PrintStream var8 = System.out;
                     String var10001 = ext.getName();
                     var8.println("Extension geladen: " + var10001 + " (v" + ext.getVersion() + "), erstellt von " + ext.getAuthor());
                     if (ext.getExtension() != null && ext.getExtension().getFilePath() != null) {
                        extensions.put(ext.getExtension().getWhere() != null ? ext.getExtension().getWhere() : "", ext.getExtension().getFilePath());
                     }

                     mods.add(new Mod(ext.getName(), String.valueOf(ext.getVersion()), ext.getAuthor(), ext.getDescription(), new ArrayList()));
                  }
               } else {
                  System.out.println("⚠️  Keine mod.json gefunden in: " + tempDir);
               }
            } catch (Exception var7) {
               System.err.println("❌ Fehler beim Verarbeiten von Mod: " + modZip.getName());
               var7.printStackTrace();
            }
         }

      }
   }

   private static Mod parseModInfo(File xmlFile, String pathDir) throws Exception {
      DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
      DocumentBuilder db = dbf.newDocumentBuilder();
      Document doc = db.parse(xmlFile);
      String name = doc.getElementsByTagName("name").item(0).getTextContent();
      String version = doc.getElementsByTagName("version").item(0).getTextContent();
      String author = doc.getElementsByTagName("author").item(0).getTextContent();
      String description = doc.getElementsByTagName("description").item(0).getTextContent();
      String extensionSrc = doc.getElementsByTagName("extension").item(0).getTextContent();
      String extensionWhere = doc.getElementsByTagName("extension").item(0).getAttributes().getNamedItem("where").getTextContent();
      extensionSrc = pathDir + "/" + extensionSrc;
      extensions.put(extensionWhere, extensionSrc);
      List<Item> items = new ArrayList();
      NodeList itemsNodes = doc.getElementsByTagName("items");
      if (itemsNodes.getLength() > 0) {
         Node itemsNode = itemsNodes.item(0);
         NodeList children = itemsNode.getChildNodes();

         for(int i = 0; i < children.getLength(); ++i) {
            Node child = children.item(i);
            if (child.getNodeName().equals("file")) {
               items.addAll(loadItemsFromFile(new File(xmlFile.getParent(), child.getTextContent())));
            } else if (child.getNodeName().equals("item")) {
               Element e = (Element)child;
               items.add(new Item(e.getAttribute("id"), e.getElementsByTagName("name").item(0).getTextContent(), e.getElementsByTagName("type").item(0).getTextContent()));
            }
         }
      }

      return new Mod(name, version, author, description, items);
   }

   public static String findMyMod(String where) {
      return (String)extensions.get(where);
   }

   private static List<Item> loadItemsFromFile(File f) throws Exception {
      List<Item> items = new ArrayList();
      if (!f.exists()) {
         return items;
      } else {
         DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
         DocumentBuilder db = dbf.newDocumentBuilder();
         Document doc = db.parse(f);
         NodeList itemNodes = doc.getElementsByTagName("item");

         for(int i = 0; i < itemNodes.getLength(); ++i) {
            Element e = (Element)itemNodes.item(i);
            items.add(new Item(e.getAttribute("id"), e.getElementsByTagName("name").item(0).getTextContent(), e.getElementsByTagName("type").item(0).getTextContent()));
         }

         return items;
      }
   }

   protected static void unzip(String zipFile, String destFolder) {
      try {
         ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFile));

         try {
            byte[] buffer = new byte[1024];

            label55:
            while(true) {
               while(true) {
                  ZipEntry entry;
                  if ((entry = zis.getNextEntry()) == null) {
                     break label55;
                  }

                  File newFile = new File(destFolder, entry.getName());
                  if (entry.isDirectory()) {
                     newFile.mkdirs();
                  } else {
                     (new File(newFile.getParent())).mkdirs();
                     FileOutputStream fos = new FileOutputStream(newFile);

                     int len;
                     try {
                        while((len = zis.read(buffer)) > 0) {
                           fos.write(buffer, 0, len);
                        }
                     } catch (Throwable var11) {
                        try {
                           fos.close();
                        } catch (Throwable var10) {
                           var11.addSuppressed(var10);
                        }

                        throw var11;
                     }

                     fos.close();
                  }
               }
            }
         } catch (Throwable var12) {
            try {
               zis.close();
            } catch (Throwable var9) {
               var12.addSuppressed(var9);
            }

            throw var12;
         }

         zis.close();
      } catch (Exception var13) {
         var13.printStackTrace();
      }

   }

   static {
      String var10002 = System.getProperty("user.home");
      modsDir = new File(var10002 + File.separator + "FnF-Apps" + File.separator + "US" + File.separator + "stable" + File.separator + "resources" + File.separator + "extensions");
   }
}
