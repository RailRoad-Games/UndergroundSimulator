// Source code is decompiled from a .class file using FernFlower decompiler (from Intellij IDEA).
package de.qstudios.underground.dev;

import java.util.TreeSet;

public class Boerse implements Comparable<Boerse> {
   public String name = "Deine Firma";
   public double kurs;
   public String[] firmen = new String[]{"Googol LLC", "Apfel Inc.", "Macrohard Corporation", "Amazonas Inc.", "Facescreen, Inc.", "NVIDA, Inc.", "Netclixx, Inc.", "The Coga-Coga Company", "Nicei, Inc.", "McRon Corporation"};
   public static TreeSet<Boerse> firmenBoerse = new TreeSet();

   public void initialize() {
      String[] var6;
      int var5 = (var6 = this.firmen).length;

      for(int var4 = 0; var4 < var5; ++var4) {
         String firma = var6[var4];
         double random = Math.random() * 10001.0;
         Boerse boerse = new Boerse(firma, random);
         firmenBoerse.add(boerse);
      }

   }

   public Boerse(String name, double kurs) {
      this.initialize();
      this.name = name;
      this.kurs = kurs;
      firmenBoerse.add(this);
   }

   public Boerse(String name) {
      this.initialize();
      this.name = name;
      Double random = Math.random() * 10001.0;
      this.kurs = random;
      firmenBoerse.add(this);
   }

   public void main(String[] args) {
      this.initialize();
   }

   public int compareTo(Boerse other) {
      return Double.compare(this.kurs, other.kurs);
   }

   public String getName() {
      return this.name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public double getKurs() {
      return this.kurs;
   }

   public void setKurs(double kurs) {
      this.kurs = kurs;
   }
}
