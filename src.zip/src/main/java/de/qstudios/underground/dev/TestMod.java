package de.qstudios.underground.dev;

import de.qstudios.underground.mod.ModJson;
import de.qstudios.underground.mod.Modfile;

public class TestMod extends ModJson implements Modfile {

    @Override
    public void activity() {
       System.out.println("");
       getLogger(this.getClass()).info("Nix");
    }

    @Override
    public void onLogin() {
    }

    @Override
    public void onLaunch() {
    }

    @Override
    public void onGameStart() {
    } 
    
    @Override
    public void onEnable() {
    }
}
