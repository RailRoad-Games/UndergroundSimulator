// Source code is decompiled from a .class file using FernFlower decompiler (from Intellij IDEA).
package de.qstudios.underground.util;

import de.qstudios.underground.dev.TrainInterface;

public class Zug implements TrainInterface {
   private int sitze;
   private String hersteller;
   private int kosten;
   private int v_max;
   private int doors;

   public Zug(int sitze, String hersteller, int v_max) {
      this.sitze = sitze;
      this.hersteller = hersteller;
      this.kosten = sitze == 120 ? 100 : 200;
      this.v_max = v_max;
      this.doors = sitze == 120 ? 4 : 6;
   }

   public int getSitze() {
      return this.sitze;
   }

   public int getDoors() {
      return this.doors;
   }

   public String getHersteller() {
      return this.hersteller;
   }

   public int getKosten() {
      return this.kosten;
   }

   public int getV_max() {
      return this.v_max;
   }
}
