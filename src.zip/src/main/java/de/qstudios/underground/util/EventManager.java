// Source code is decompiled from a .class file using FernFlower decompiler (from Intellij IDEA).
package de.qstudios.underground.util;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Paths;
import java.util.concurrent.ThreadLocalRandom;

import com.google.gson.Gson;

public class EventManager {
   Event[] karten = new Event[]{new Event(-100, 0, 0, -1, "Überschwemmung! Eine Ihrer Strecken steht Ihnen aktuell nicht zur Verfügung. Die Reparaturkosten belaufen sich auf 100€!"), new Event(0, -1, 0, 0, "Fahrer erkrankt! Einer Ihrer Züge kann heute nicht fahren, da der zugewiesene Fahrer erkrankt ist."), new Event(-20, 0, -1, 0, "Verdammte Teenager! Laut Zeugen wurde gestern einer unserer Züge mit Graffiti besprüht, das bedeutet, dass er für 20€ gesäubert werden muss."), new Event(-30, 0, -1, 0, "Es war Volksfest! Einer deiner Züge ist durch betrunkene Menschen verschmutzt, ein Tag lang werden diese für 10€ pro Zug gereinigt."), new Event(0, -1, 0, 1, "Ferien! Deine Firma verdient mehr Geld, da viele Leute mitfahren wollen. Du verlierst für die Runde einen Fahrer."), new Event(0, 0, 0, 0, "Normaler Betrieb. Es passiert nichts."), new Event(0, 0, 0, 0, "Normaler Betrieb. Es passiert nichts."), new Event(0, 0, 0, 0, "Normaler Betrieb. Es passiert nichts."), new Event(0, 0, 0, 0, "Normaler Betrieb. Es passiert nichts."), new Event(0, 0, 0, 0, "Normaler Betrieb. Es passiert nichts.")};

   public EventManager() {
      try {
         String var10000 = System.getProperty("user.home");
         String filePath = var10000 + File.separator + "FnF-Apps" + File.separator + "US" + File.separator + "stable" + File.separator + "resources" + File.separator + "events.json";
         if (Files.exists(Paths.get(filePath), new LinkOption[0]) && Files.isReadable(Paths.get(filePath))) {
            this.karten = (Event[])(new Gson()).fromJson(Files.readString(Paths.get(filePath)), Event[].class);
         } else {
            System.out.println("Die Datei 'events.json' wurde nicht gefunden. Es wird mit Standardkarten gearbeitet.");
         }
      } catch (Exception var2) {
         System.out.println("Fehler beim Laden der Karte-Datei: " + var2.getMessage());
         var2.printStackTrace();
      }

   }

   public Event getEvent() {
      int randomNummer = ThreadLocalRandom.current().nextInt(this.karten.length);
      return this.karten[randomNummer];
   }
}
