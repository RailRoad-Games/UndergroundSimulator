package de.qstudios.underground.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mpatric.mp3agic.InvalidDataException;
import com.mpatric.mp3agic.Mp3File;
import com.mpatric.mp3agic.UnsupportedTagException;

import de.qstudios.underground.Main;

import org.slf4j.*;
import javazoom.jl.player.Player;

public class Radio {
    private static final Logger LOG = LoggerFactory.getLogger(Radio.class);
    private static final Path RADIO_JSON = Path.of(
            System.getProperty("user.home"),
            "FnF-Apps",
            "US",
            "stable",
            "resources",
            "radio.json");

    private static final List<RadioSong> songs = new ArrayList<>();
    private static int currentIndex = 0;

    public static void startRadio() {
        testRadioJson();
        loadSongs();
        System.out.println(">>> startRadio() wurde aufgerufen");

        if (songs.isEmpty()) {
            System.out.println("Keine Songs gefunden.");
            return;
        }

        new Thread(() -> {
            try {
                RadioSong song = playNext();

                try (FileInputStream fis = new FileInputStream(song.getFile().getAbsoluteFile())) {
                    LOG.info(">>> startRadio() versucht, Song zu Spielen");
                    LOG.info("Spiele Datei: " + song.getFile().getAbsolutePath());
                    Player player = new Player(fis);
                    LOG.info("Player erstellt");
                    player.play(); // blockiert bis Song fertig ist
                    LOG.info("Player fertiggespielt");
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    private static void loadSongs() {
        try {
            String json = Files.readString(RADIO_JSON);
            List<RadioSong> loaded = new Gson().fromJson(
                    json,
                    new TypeToken<List<RadioSong>>() {
                    }.getType());

            songs.clear();
            boolean downloadErlaubt = false;
            for (RadioSong rs : loaded) {
                if (!rs.getFile().getAbsoluteFile().exists()) {
                    if (downloadErlaubt) {
                        downloadMusic(rs.file);
                    } else {
                        String akzeptiert = Main
                                .readstring("Es wurden einige Radiodateien lokal nicht gefunden, downloaden?");
                        switch (akzeptiert) {
                            case "N":
                            case "n":
                                return;
                            default:
                                downloadErlaubt = true;
                                downloadMusic(rs.file);
                                break;
                        }
                    }
                }
            }
            if (loaded != null) {
                songs.addAll(loaded);
            }
        } catch (IOException e) {
            System.err.println("Fehler beim Laden von radio.json:");
            e.printStackTrace();
        }
    }

    private static RadioSong playNext() {
        currentIndex++;
        if (currentIndex >= songs.size()) {
            currentIndex = 0;
        }

        RadioSong song = songs.get(currentIndex);
        File file = song.getFile();
        if (!file.exists()) {
            System.out.println("Datei nicht gefunden: " + file.getAbsolutePath());
            return null;
        }
        // playFile(file);
        return song;
    }

    public static void main(String[] args) {
        startRadio();
    }

    public class RadioSong {

        // Felder müssen public oder mit Getter zugänglich sein, damit Gson sie befüllen
        // kann
        public String name;
        public String artist;
        public String album;
        public String genre;
        public String year;
        public String file;
        public long length;

        // Leerer Konstruktor für Gson (wichtig!)
        public RadioSong() {
        }

        // Optionaler Komfort-Konstruktor (falls du Songs manuell erstellst)
        public RadioSong(String name, String artist, String album,
                String genre, String year, String file) {
            this.name = name;
            this.artist = artist;
            this.album = album;
            this.genre = genre;
            this.year = year;
            this.file = file;
            try {
                Mp3File mp3file = new Mp3File(file);
                length = mp3file.getLength();
            } catch (InvalidDataException | UnsupportedTagException | IOException e) {
                length = 0;
            }
        }

        /**
         * Gibt die tatsächliche MP3-Datei zurück.
         * Hier kannst du zentral den Musikordner definieren.
         */
        public File getFile() {
            return new File(
                    System.getProperty("user.home")
                            + File.separator + "FnF-Apps"
                            + File.separator + "US"
                            + File.separator + "stable"
                            + File.separator + "resources"
                            + File.separator + "music"
                            + File.separator + file);
        }

        /**
         * Prüft, ob die Datei wirklich existiert.
         */
        public boolean exists() {
            return getFile().exists();
        }

        /**
         * Schöne Konsolen-Ausgabe.
         */
        @Override
        public String toString() {
            return artist + " – " + name + " (" + album + ", " + year + ")";
        }

    }

    public static void downloadMusic(String music) {
        try {
            String url = "https://us-data.deepslatesmp.de/" + music;
            HttpClient client = HttpClient.newBuilder()
                    .followRedirects(HttpClient.Redirect.ALWAYS) // sehr wichtig
                    .build();

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .build();

            System.out.println("Downloading " + music + " from " + url);

            // ⚡ Hier: BodyHandlers.ofByteArray() statt ofString()
            HttpResponse<byte[]> response = client.send(request, HttpResponse.BodyHandlers.ofByteArray());

            if (response.statusCode() != 200) {
                System.out.println("Fehler: HTTP " + response.statusCode());
                return;
            }

            // Speicher die Datei korrekt als Binär
            Path path = Path.of(System.getProperty("user.home"), "FnF-Apps", "US", "stable", "resources", "music",
                    music);
            if (music.equalsIgnoreCase("radio.json")) {
                path = Path.of(System.getProperty("user.home"), "FnF-Apps", "US", "stable", "resources", music);
            }
            else if (music.equalsIgnoreCase("radio-baldi.json")){
                path = Path.of(System.getProperty("user.home"), "FnF-Apps", "US", "stable", "resources","radio.json");
            }
            Files.createDirectories(path.getParent()); // sicherstellen, dass Ordner existieren
            Files.write(path, response.body(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);

            System.out.println("Download fertig: " + path);

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void testRadioJson() {
        File radioJson = RADIO_JSON.toFile();
        boolean exists = radioJson.exists();
        if (!exists) {
            if (Main.baldiMode) {
                //downloadMusic("radio-baldi.json");
            } else {
                downloadMusic("radio.json");
            }
        } else {
            return;
        }
    }

}
