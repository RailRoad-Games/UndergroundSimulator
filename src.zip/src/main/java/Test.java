import de.jexe.core.*;

public class Test {
    public static void main(String[] args) throws InterruptedException {
        JExeServer jserver = JExeServer.builder().port(2119).maxClients(20).build();
        jserver.start();
        JExeClient client = new JExeClient();
        client.connect("localhost", 2119);
        client.disconnect();
        Thread.currentThread().join();
    }
}
